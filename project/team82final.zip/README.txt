# Stock-trendz

Team project for DVA course: Team81

# DESCRIPTION:

Various Fin-Tech platforms have started offering intuitive web-based  stock  analysis  applications, which a client can utilize for algorithmic trading.But none of these currently offer a way to includestock’s underlying sentiment on the web (news,Twitter or even Google trends) in a client’s model for stock price prediction/trend analysis. We pro-pose to build an experimental tool which integrates with online sentiments along with statistical mar-ket indicators for client’s use.

This repository serve contains the following modules:

## Front End(Angular JS):

* Angular Js : To visualize the stock trends using the trained model in a User Interface.
* Bootstrap: CSS decorating framework.



## Back End(Python Flask)

This is the backend where all the logic and machine learning models were written.


# INSTALLATION:


## Prerequisite:
* Angular Js version6
* python 2.7
* nodejs
* virtualenv

## Steps:

### Install UI
```
git clone https://github.gatech.edu/gpande3/Stock-trendz
cd Stock-trendz/frontend
npm install
```

#### Run the UI 
```
cd Stock-trendz/frontend
ng serve

```

The front end should be running on : localhost:4200


### Install backend

The backend is where the modelsa are written.

#### Install virtual environment and necessary libraries
```
cd Stock-trendz/backend
virtualenv venv
source venv/bin/activate
pip install -r requirements.txt
```

#### Run backend
```
cd  Stock-trendz/backend
python webapp.py
```

The backend should not be running at : localhost:8080
you dont need to run this on browser as this is already integrated with the front end.




# EXECUTION: 

### Backend:

The backend should be running on localhost:3000

#### Run backend
```
cd  Stock-trendz/backend
python webapp.py
```


### Frontend

The frontend should be running on localhost:4200

#### Run the UI 
```
cd Stock-trendz/frontend
ng serve

```


## NOTE: PLEASE DO NOT SELECT TWEETER OPTION DURING OFF MARKET HOURS.




